# -*- coding: utf-8 -*-
__author__ = 'wenyao'

listen_port = 5000

# mysql = {
#     'host'  :'192.168.0.201',
#     'user'  :'wenyao',
#     'password':'wenyao',
#     'port'  :3306,
#     'database'    :'flasktest',
#     'db-connection-pool' :100
# }


mysql = {
    'host'  :'192.168.160.130',
    'user'  :'root',
    'password':'flask-test',
    'port'  :3306,
    'database'    :'flasktest',
    'db-connection-pool' :100
}


memcache_servers = ['192.168.160.130:11211']

session_expire_time = 6000

auth_enable = True
SECRET_KEY = '123456'



