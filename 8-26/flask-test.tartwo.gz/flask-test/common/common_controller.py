from flask_restful import Resource
from flask import current_app,request


class Restapi(Resource):

    def get(self):
        pass
    
    def post(self):
        pass
    
    def put(self):
        pass
    
    def delete(self):
        pass
      
    def options(self):
        pass

