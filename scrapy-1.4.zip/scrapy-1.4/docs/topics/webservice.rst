.. _topics-webservice:

===========
Web Service
===========

webservice has been moved into a separate project.

It is hosted at:

    https://github.com/scrapy-plugins/scrapy-jsonrpc
