# -*- coding: utf-8 -*-
__author__ = 'wenyao'

listen_port = 5000

mysql = {
    'host'  :'192.168.160.130',
    'user'  :'root',
    'password':'flask-test',
    'port'  :3306,
    'database'    :'flasktest',
    'db-connection-pool' :100
}



